let output=document.getElementById('result');
let btn = document.getElementById("btn");
let hint = document.getElementById("hint");

let number= Math.floor(Math.random()*5)+1;
let count=0;
let maxTries=3;
btn.addEventListener('click', function(){
    let play= parseInt(document.getElementById("play").value);
    count++;
    if(play==number){
        output.innerHTML="your guess is right";

        output.style.color = "green";
    }
    else if(play>number){
        output.innerHTML="your guess is wrong!";
        hint.innerHTML=`your guess number is too high 
        guess no-${count}`;
    }
    else if(play<number){
        output.innerHTML="your guess is wrong!";
        output.style.color = "red";
        hint.innerHTML=`your guess number is too low
        guess no- ${count}`;
    }
// If guess is correct, remove the event listener to stop further guessing
      // If guess is correct or if maximum tries exceeded, remove the event listener to stop further guessing
      if (play === number || count >= maxTries) {
        if (count >= maxTries && play !== number) {
            output.innerHTML = `Sorry, you've exceeded the maximum number of tries (${maxTries})! The correct number was ${number}.`;
        }
        btn.removeEventListener('click', this);
    }
});